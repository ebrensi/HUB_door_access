Included in this folder are two files: an executable file report_parse.exe, and its python source code report_parse.py

The application parses a text file report output by the Integra Link software and outputs a csv file called output.csv.

 

report_parse.exe can either be run in a DOS terminal console as  

report_parse myfile.txt

or you can put the exe file on your desktop and drag a text file onto it.  
The output file will appear in the same folder as the text file.
  

If you have any questions, contact me at Rensi.Efrem@gmail.com



 